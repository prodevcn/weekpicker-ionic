(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
    /***/
    "./node_modules/@ionic-native/wheel-selector/__ivy_ngcc__/ngx/index.js":
    /*!*****************************************************************************!*\
      !*** ./node_modules/@ionic-native/wheel-selector/__ivy_ngcc__/ngx/index.js ***!
      \*****************************************************************************/

    /*! exports provided: WheelSelector */

    /***/
    function node_modulesIonicNativeWheelSelector__ivy_ngcc__NgxIndexJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "WheelSelector", function () {
        return WheelSelector;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_native_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic-native/core */
      "./node_modules/@ionic-native/core/__ivy_ngcc__/index.js");

      var WheelSelector =
      /** @class */
      function (_super) {
        Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__extends"])(WheelSelector, _super);

        function WheelSelector() {
          return _super !== null && _super.apply(this, arguments) || this;
        }

        WheelSelector.prototype.show = function (options) {
          return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "show", {}, arguments);
        };

        WheelSelector.prototype.hideSelector = function () {
          return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["cordova"])(this, "hideSelector", {
            "platforms": ["iOS"]
          }, arguments);
        };

        WheelSelector.pluginName = "WheelSelector";
        WheelSelector.plugin = "cordova-wheel-selector-plugin";
        WheelSelector.pluginRef = "SelectorCordovaPlugin";
        WheelSelector.repo = "https://github.com/jasonmamy/cordova-wheel-selector-plugin";
        WheelSelector.platforms = ["Android", "iOS"];

        WheelSelector.ɵfac = function WheelSelector_Factory(t) {
          return ɵWheelSelector_BaseFactory(t || WheelSelector);
        };

        WheelSelector.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
          token: WheelSelector,
          factory: function factory(t) {
            return WheelSelector.ɵfac(t);
          }
        });

        var ɵWheelSelector_BaseFactory = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetInheritedFactory"](WheelSelector);
        /*@__PURE__*/


        (function () {
          _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵsetClassMetadata"](WheelSelector, [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"]
          }], null, null);
        })();

        return WheelSelector;
      }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_2__["IonicNativePlugin"]); //# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9AaW9uaWMtbmF0aXZlL3BsdWdpbnMvd2hlZWwtc2VsZWN0b3Ivbmd4L2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sOEJBQXNDLE1BQU0sb0JBQW9CLENBQUM7O0FBQ3hFO0FBRWlCLElBa0xrQixpQ0FBaUI7QUFBQztBQUU5QjtBQUMyQztBQUFNLElBSXRFLDRCQUFJLGFBQUMsT0FBNkI7QUFJakMsSUFPRCxvQ0FBWTtBQUkyQztBQUFnRDtBQUE0RDtBQUF1RDtBQUF1RjtJQXRCdFMsYUFBYSx3QkFEekIsVUFBVSxFQUFFLFFBQ0EsYUFBYTs7Ozs7MEJBQUU7QUFBQyx3QkF0TDdCO0FBQUUsRUFzTGlDLGlCQUFpQjtBQUNuRCxTQURZLGFBQWE7QUFBSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvcmRvdmEsIElvbmljTmF0aXZlUGx1Z2luLCBQbHVnaW4gfSBmcm9tICdAaW9uaWMtbmF0aXZlL2NvcmUnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFdoZWVsU2VsZWN0b3JJdGVtIHtcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGVmYXVsdEl0ZW0ge1xuICBpbmRleDogbnVtYmVyO1xuICB2YWx1ZTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFdoZWVsU2VsZWN0b3JPcHRpb25zIHtcbiAgLyoqXG4gICAqIFRoZSB0aXRsZSBvZiB0aGUgc2VsZWN0b3IncyBpbnB1dCBib3hcbiAgICovXG4gIHRpdGxlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBpdGVtcyB0byBkaXNwbGF5IChhcnJheSBvZiBpdGVtcykuXG4gICAqL1xuICBpdGVtczogV2hlZWxTZWxlY3Rvckl0ZW1bXVtdO1xuXG4gIC8qKlxuICAgKiBXaGljaCBpdGVtcyB0byBkaXNwbGF5IGJ5IGRlZmF1bHQuXG4gICAqL1xuICBkZWZhdWx0SXRlbXM/OiBEZWZhdWx0SXRlbVtdO1xuXG4gIC8qKlxuICAgKiBUaGUgJ29rJyBidXR0b24gdGV4dFxuICAgKiBEZWZhdWx0OiBEb25lXG4gICAqL1xuICBwb3NpdGl2ZUJ1dHRvblRleHQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSAnY2FuY2VsJyBidXR0b24gdGV4dFxuICAgKiBEZWZhdWx0OiBDYW5jZWxcbiAgICovXG4gIG5lZ2F0aXZlQnV0dG9uVGV4dD86IHN0cmluZztcblxuICAvKipcbiAgICogQW5kcm9pZCBvbmx5IC0gdGhlbWUgY29sb3IsICdsaWdodCcgb3IgJ2RhcmsnLlxuICAgKiBEZWZhdWx0OiBsaWdodFxuICAgKi9cbiAgdGhlbWU/OiAnbGlnaHQnIHwgJ2RhcmsnO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGhhdmUgdGhlIHdoZWVscyAnd3JhcCcgKEFuZHJvaWQgb25seSlcbiAgICogRGVmYXVsdDogZmFsc2VcbiAgICovXG4gIHdyYXBXaGVlbFRleHQ/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBUaGUganNvbiBrZXkgdG8gZGlzcGxheSwgYnkgZGVmYXVsdCBpdCBpcyBkZXNjcmlwdGlvbiwgdGhpcyBhbGxvd3MgZm9yIHNldHRpbmcgYW55XG4gICAqIGtleS92YWx1ZSB0byBiZSBkaXNwbGF5ZWRcbiAgICogRGVmYXVsdDogZGVzY3JpcHRpb25cbiAgICovXG4gIGRpc3BsYXlLZXk/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgV2hlZWxTZWxlY3RvckRhdGEge1xuICBkYXRhOiBhbnk7XG59XG5cbi8qKlxuICogQGJldGFcbiAqIEBuYW1lIFdoZWVsU2VsZWN0b3IgUGx1Z2luXG4gKiBAZGVzY3JpcHRpb24gTmF0aXZlIHdoZWVsIHNlbGVjdG9yIGZvciBDb3Jkb3ZhIChBbmRyb2lkL2lPUykuXG4gKlxuICogQHVzYWdlXG4gKiBgYGBcbiAqIGltcG9ydCB7IFdoZWVsU2VsZWN0b3IgfSBmcm9tICdAaW9uaWMtbmF0aXZlL3doZWVsLXNlbGVjdG9yL25neCc7XG4gKlxuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgc2VsZWN0b3I6IFdoZWVsU2VsZWN0b3IpIHsgfVxuICpcbiAqIC4uLlxuICpcbiAqIGNvbnN0IGpzb25EYXRhID0ge1xuICogICBudW1iZXJzOiBbXG4gKiAgICB7IGRlc2NyaXB0aW9uOiBcIjFcIiB9LFxuICogICAgIHsgZGVzY3JpcHRpb246IFwiMlwiIH0sXG4gKiAgICAgeyBkZXNjcmlwdGlvbjogXCIzXCIgfVxuICogICBdLFxuICogICBmcnVpdHM6IFtcbiAqICAgICB7IGRlc2NyaXB0aW9uOiBcIkFwcGxlXCIgfSxcbiAqICAgICB7IGRlc2NyaXB0aW9uOiBcIkJhbmFuYVwiIH0sXG4gKiAgICAgeyBkZXNjcmlwdGlvbjogXCJUYW5nZXJpbmVcIiB9XG4gKiAgIF0sXG4gKiAgIGZpcnN0TmFtZXM6IFtcbiAqICAgICB7IG5hbWU6IFwiRnJlZFwiLCBpZDogJzEnIH0sXG4gKiAgICAgeyBuYW1lOiBcIkphbmVcIiwgaWQ6ICcyJyB9LFxuICogICAgIHsgbmFtZTogXCJCb2JcIiwgaWQ6ICczJyB9LFxuICogICAgIHsgbmFtZTogXCJFYXJsXCIsIGlkOiAnNCcgfSxcbiAqICAgICB7IG5hbWU6IFwiRXVuaWNlXCIsIGlkOiAnNScgfVxuICogICBdLFxuICogICBsYXN0TmFtZXM6IFtcbiAqICAgICB7IG5hbWU6IFwiSm9obnNvblwiLCBpZDogJzEwMCcgfSxcbiAqICAgICB7IG5hbWU6IFwiRG9lXCIsIGlkOiAnMTAxJyB9LFxuICogICAgIHsgbmFtZTogXCJLaW5pc2hpd2FcIiwgaWQ6ICcxMDInIH0sXG4gKiAgICAgeyBuYW1lOiBcIkdvcmRvblwiLCBpZDogJzEwMycgfSxcbiAqICAgICB7IG5hbWU6IFwiU21pdGhcIiwgaWQ6ICcxMDQnIH1cbiAqICAgXVxuICogfVxuICpcbiAqIC4uLlxuICpcbiAqIC8vIGJhc2ljIG51bWJlciBzZWxlY3Rpb24sIGluZGV4IGlzIGFsd2F5cyByZXR1cm5lZCBpbiB0aGUgcmVzdWx0XG4gKiAgc2VsZWN0QU51bWJlcigpIHtcbiAqICAgIHRoaXMuc2VsZWN0b3Iuc2hvdyh7XG4gKiAgICAgIHRpdGxlOiBcIkhvdyBNYW55P1wiLFxuICogICAgICBpdGVtczogW1xuICogICAgICAgIHRoaXMuanNvbkRhdGEubnVtYmVyc1xuICogICAgICBdLFxuICogICAgfSkudGhlbihcbiAqICAgICAgcmVzdWx0ID0+IHtcbiAqICAgICAgICBjb25zb2xlLmxvZyhyZXN1bHRbMF0uZGVzY3JpcHRpb24gKyAnIGF0IGluZGV4OiAnICsgcmVzdWx0WzBdLmluZGV4KTtcbiAqICAgICAgfSxcbiAqICAgICAgZXJyID0+IGNvbnNvbGUubG9nKCdFcnJvcjogJywgZXJyKVxuICogICAgICApO1xuICogIH1cbiAqXG4gKiAgLi4uXG4gKlxuICogIC8vIGJhc2ljIHNlbGVjdGlvbiwgc2V0dGluZyBpbml0aWFsIGRpc3BsYXllZCBkZWZhdWx0IHZhbHVlczogJzMnICdCYW5hbmEnXG4gKiAgc2VsZWN0RnJ1aXQoKSB7XG4gKiAgICB0aGlzLnNlbGVjdG9yLnNob3coe1xuICogICAgICB0aXRsZTogXCJIb3cgTXVjaD9cIixcbiAqICAgICAgaXRlbXM6IFtcbiAqICAgICAgICB0aGlzLmpzb25EYXRhLm51bWJlcnMsIHRoaXMuanNvbkRhdGEuZnJ1aXRzXG4gKiAgICAgIF0sXG4gKiAgICAgIHBvc2l0aXZlQnV0dG9uVGV4dDogXCJPa1wiLFxuICogICAgICBuZWdhdGl2ZUJ1dHRvblRleHQ6IFwiTm9wZVwiLFxuICogICAgICBkZWZhdWx0SXRlbXM6IFtcbiAqICBcdCAge2luZGV4OjAsIHZhbHVlOiB0aGlzLmpzb25EYXRhLm51bWJlcnNbMl0uZGVzY3JpcHRpb259LFxuICogIFx0ICB7aW5kZXg6IDEsIHZhbHVlOiB0aGlzLmpzb25EYXRhLmZydWl0c1szXS5kZXNjcmlwdGlvbn1cbiAqICBcdF1cbiAqICAgIH0pLnRoZW4oXG4gKiAgICAgIHJlc3VsdCA9PiB7XG4gKiAgICAgICAgY29uc29sZS5sb2cocmVzdWx0WzBdLmRlc2NyaXB0aW9uICsgJyAnICsgcmVzdWx0WzFdLmRlc2NyaXB0aW9uKTtcbiAqICAgICAgfSxcbiAqICAgICAgZXJyID0+IGNvbnNvbGUubG9nKCdFcnJvcjogJyArIEpTT04uc3RyaW5naWZ5KGVycikpXG4gKiAgICAgICk7XG4gKiAgfVxuICpcbiAqICAuLi5cbiAqXG4gKiAgLy8gbW9yZSBjb21wbGV4IGFzIG92ZXJyaWRlcyB3aGljaCBrZXkgdG8gZGlzcGxheVxuICogIC8vIHRoZW4gcmV0cmlldmUgcHJvcGVydGllcyBmcm9tIG9yaWdpbmFsIGRhdGFcbiAqICBzZWxlY3ROYW1lc1VzaW5nRGlzcGxheUtleSgpIHtcbiAqICAgIHRoaXMuc2VsZWN0b3Iuc2hvdyh7XG4gKiAgICAgIHRpdGxlOiBcIldobz9cIixcbiAqICAgICAgaXRlbXM6IFtcbiAqICAgICAgICB0aGlzLmpzb25EYXRhLmZpcnN0TmFtZXMsIHRoaXMuanNvbkRhdGEubGFzdE5hbWVzXG4gKiAgICAgIF0sXG4gKiAgICAgIGRpc3BsYXlLZXk6ICduYW1lJyxcbiAqICAgICAgZGVmYXVsdEl0ZW1zOiBbXG4gKiAgXHQgIHtpbmRleDowLCB2YWx1ZTogdGhpcy5qc29uRGF0YS5maXJzdE5hbWVzWzJdLm5hbWV9LFxuICogICAgICAgIHtpbmRleDogMCwgdmFsdWU6IHRoaXMuanNvbkRhdGEubGFzdE5hbWVzWzNdLm5hbWV9XG4gKiAgICAgIF1cbiAqICAgIH0pLnRoZW4oXG4gKiAgICAgIHJlc3VsdCA9PiB7XG4gKiAgICAgICAgY29uc29sZS5sb2cocmVzdWx0WzBdLm5hbWUgKyAnIChpZD0gJyArIHRoaXMuanNvbkRhdGEuZmlyc3ROYW1lc1tyZXN1bHRbMF0uaW5kZXhdLmlkICsgJyksICcgK1xuICogICAgICAgICAgcmVzdWx0WzFdLm5hbWUgKyAnIChpZD0nICsgdGhpcy5qc29uRGF0YS5sYXN0TmFtZXNbcmVzdWx0WzFdLmluZGV4XS5pZCArICcpJyk7XG4gKiAgICAgIH0sXG4gKiAgICAgIGVyciA9PiBjb25zb2xlLmxvZygnRXJyb3I6ICcgKyBKU09OLnN0cmluZ2lmeShlcnIpKVxuICogICAgICApO1xuICogIH1cbiAqXG4gKiBgYGBcbiAqXG4gKiBAaW50ZXJmYWNlc1xuICogV2hlZWxTZWxlY3Rvck9wdGlvbnNcbiAqL1xuQFBsdWdpbih7XG4gIHBsdWdpbk5hbWU6ICdXaGVlbFNlbGVjdG9yJyxcbiAgcGx1Z2luOiAnY29yZG92YS13aGVlbC1zZWxlY3Rvci1wbHVnaW4nLFxuICBwbHVnaW5SZWY6ICdTZWxlY3RvckNvcmRvdmFQbHVnaW4nLFxuICByZXBvOiAnaHR0cHM6Ly9naXRodWIuY29tL2phc29ubWFteS9jb3Jkb3ZhLXdoZWVsLXNlbGVjdG9yLXBsdWdpbicsXG4gIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUyddLFxufSlcbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBXaGVlbFNlbGVjdG9yIGV4dGVuZHMgSW9uaWNOYXRpdmVQbHVnaW4ge1xuICAvKipcbiAgICogU2hvd3MgdGhlIHdoZWVsIHNlbGVjdG9yXG4gICAqIEBwYXJhbSB7V2hlZWxTZWxlY3Rvck9wdGlvbnN9IG9wdGlvbnMgT3B0aW9ucyBmb3IgdGhlIHdoZWVsIHNlbGVjdG9yXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPFdoZWVsU2VsZWN0b3JEYXRhPn0gUmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBzZWxlY3RlZCBpdGVtcywgb3IgYW4gZXJyb3IuXG4gICAqL1xuICBAQ29yZG92YSgpXG4gIHNob3cob3B0aW9uczogV2hlZWxTZWxlY3Rvck9wdGlvbnMpOiBQcm9taXNlPFdoZWVsU2VsZWN0b3JEYXRhPiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIEhpZGUgdGhlIHNlbGVjdG9yXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPHZvaWQ+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydpT1MnXSxcbiAgfSlcbiAgaGlkZVNlbGVjdG9yKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHJldHVybjtcbiAgfVxufVxuIl19

      /***/

    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
    /*!***************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Select Week\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <ion-header collapse=\"condense\">\n    <ion-toolbar>\n      <ion-title size=\"large\">Please select week</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-button expand='full' (click) = \"openPicker()\">Open Picker</ion-button>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/home/home-routing.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/home/home-routing.module.ts ***!
      \*********************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home/home.module.ts":
    /*!*************************************!*\
      !*** ./src/app/home/home.module.ts ***!
      \*************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");
      /* harmony import */


      var _ionic_native_wheel_selector_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/wheel-selector/ngx */
      "./node_modules/@ionic-native/wheel-selector/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/home/home-routing.module.ts");

      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_7__["HomePageRoutingModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]],
        providers: [_ionic_native_wheel_selector_ngx__WEBPACK_IMPORTED_MODULE_6__["WheelSelector"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/home/home.page.scss":
    /*!*************************************!*\
      !*** ./src/app/home/home.page.scss ***!
      \*************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBRUEsa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQUFGOztBQUdBO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFFQSxjQUFBO0VBRUEsU0FBQTtBQUZGOztBQUtBO0VBQ0UscUJBQUE7QUFGRiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIjY29udGFpbmVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcblxuICBjb2xvcjogIzhjOGM4YztcblxuICBtYXJnaW46IDA7XG59XG5cbiNjb250YWluZXIgYSB7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/home/home.page.ts":
    /*!***********************************!*\
      !*** ./src/app/home/home.page.ts ***!
      \***********************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_native_wheel_selector_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic-native/wheel-selector/ngx */
      "./node_modules/@ionic-native/wheel-selector/__ivy_ngcc__/ngx/index.js");

      var HomePage = /*#__PURE__*/function () {
        function HomePage(toastCtrl, selector) {
          _classCallCheck(this, HomePage);

          this.toastCtrl = toastCtrl;
          this.selector = selector;
          this.dummyJson = {
            days: [{
              description: 'Mon'
            }, {
              description: 'Tue'
            }, {
              description: 'Wed'
            }, {
              description: 'Thu'
            }, {
              description: 'Fri'
            }],
            people: [{
              description: 'Mike'
            }, {
              description: 'Max'
            }, {
              description: 'Adam'
            }, {
              description: 'Brandy'
            }, {
              description: 'Ben'
            }]
          };
        }

        _createClass(HomePage, [{
          key: "openPicker",
          value: function openPicker() {
            var _this = this;

            var name = new Date();
            console.log(name);
            this.selector.show({
              title: 'Select your Content',
              positiveButtonText: 'Choose',
              negativeButtonText: 'Nah',
              items: [this.dummyJson.days, this.dummyJson.people],
              defaultItems: [{
                index: 0,
                value: this.dummyJson.days[4].description
              }, {
                index: 1,
                value: this.dummyJson.days[1].description
              }]
            }).then(function (result) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                var msg, toast;
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        msg = "Selected ".concat(result[0].description, " with ").concat(result[1].description);
                        _context.next = 3;
                        return this.toastCtrl.create({
                          message: msg,
                          duration: 4000
                        });

                      case 3:
                        toast = _context.sent;
                        toast.present();

                      case 5:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            });
          }
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
        }, {
          type: _ionic_native_wheel_selector_ngx__WEBPACK_IMPORTED_MODULE_3__["WheelSelector"]
        }];
      };

      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home-home-module-es5.js.map